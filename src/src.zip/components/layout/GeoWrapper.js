import React, { Component } from 'react'
import GeoLocation from './GeoLocation'

class GeoWrapper extends Component {
    state = {
        timer: null,
        coords: null,
        key: new Date().getTime(),
        cnt: 0, 
    }

    handleSetCoords = (coords) => {
        this.setState({ coords })
    }
    componentDidMount = () => {
        this.setState({
            timer: window.setInterval(this.checkCoords, 2000),
        })
    }
    checkCoords = () => {
        const { coords } = this.state;
        
        if (coords) {
            window.clearInterval(this.state.timer);
        }
        else {
            window.location.reload();
            this.setState({
                key: new Date().getTime(),
                cnt: this.state.cnt + 1,
            })
        }
    }
    render() {
        console.log(this.state);
        return (
            <div>
                <GeoLocation setCoords={this.handleSetCoords} key={this.state.key} cnt={this.state.cnt} />
            </div>
        )
    }
}

export default GeoWrapper