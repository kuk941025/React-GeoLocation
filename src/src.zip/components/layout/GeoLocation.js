import React, { Component } from 'react'
import { geolocated } from 'react-geolocated'

class GeoLocation extends Component {
    state = {
        data: [
            { name: '성신여대 CGV', lat: 37.592526, lon: 127.016974 },
            { name: '피자헛', lat: 37.592134, lon: 127.017755 },
            { name: '한성대입구역', lat: 37.588491, lon: 127.006194 },
            { name: '부산', lat: 35.145806, lon: 129.028514 },
            { name: '노트북', lat: 37.592483099999995, lon: 127.0078127 },
            { name: '삼성역', lat: 37.5101191, lon: 127.0660987},
            { name: '집', lat: 37.5341056, lon: 126.9661696}
        ],
    }
    getDistance = (coord1, coord2) => {
        var p = 0.017453292519943295;    // Math.PI / 180
        var c = Math.cos;
        var lat1 = coord1.latitude;
        var lon1 = coord1.longitude;
        var lat2 = coord2.latitude;
        var lon2 = coord2.longitude;

        var a = 0.5 - c((lat2 - lat1) * p) / 2 +
            c(lat1 * p) * c(lat2 * p) *
            (1 - c((lon2 - lon1) * p)) / 2;

        var distance = 12742 * Math.asin(Math.sqrt(a));
        return distance;

    }
    componentDidUpdate = prevs => {
        const { data } = this.state;
        const { coords } = this.props;
        
        if (prevs.coords !== coords && coords) {
            this.props.setCoords(coords);
            data.forEach(item => {
                var dist = this.getDistance({ longitude: 126.9897196, latitude: 37.5381232 }, { latitude: item.lat, longitude: item.lon });
                console.log(item.name + ": " + dist * 1000 + 'm');
            });
        }
    }
    componentDidMount = () => {
        console.log(this.props);
    }

    render() {
        const { isGeolocationAvailable, isGeolocationEnabled, coords, cnt } = this.props;
        return (
            <div>
                {!isGeolocationAvailable ? (
                    <p>위치정보를 지원하지 않는 브라우저입니다.</p>
                ) : (
                        !isGeolocationEnabled ? (
                            <p>권한없음</p>
                        ) : (
                                coords ? (
                                    <React.Fragment>
                                        <p>Latitude: {coords.latitude}</p>
                                        <p>Longitude: {coords.longitude}</p>
                                    </React.Fragment>
                                ) : (
                                        <React.Fragment>
                                            <div>
                                                위치 정보를 켜주세요. + {cnt}
                                                {isGeolocationAvailable ? ("권한잇음") : "권한없음"}
                                            </div>
                                            {this.props.positionError && <p>{this.props.positionError}</p>}
                                        </React.Fragment>

                                    )

                            )
                    )}
            </div>
        )
    }
}

export default geolocated({
    positionOptions: {
        enableHighAccuracy: false,
    },
    userDecisionTimeout: 5000
})(GeoLocation)