import './App.css'
import React, { Component } from 'react'
import { BrowserRouter, Switch, Route } from 'react-router-dom'
import GeoWrapper from './components/layout/GeoWrapper'

class App extends Component {
  render() {
    return (
      <div className="App">
        <GeoWrapper />
      </div>
    )
  }
}

export default App
